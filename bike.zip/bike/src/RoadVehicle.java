abstract class RoadVehicle 
{
	abstract void move() ;
}
