
/* Read a number from a user, create a method which accepts the number as input and returns the length of a number. */

import java.util.Scanner;

class p7
{
	static Scanner s = new Scanner(System.in);

	static int count(int num)
	{	
		int count=0;
		while (num>0)
		{
			num/=10;
			count++;
		}
		return count;
	}

	public static void main(String[] args) 
	{
		System.out.println("Enter the number:");
		int num = s.nextInt();       //5687
		System.out.println("The length of the number:" + count(num));
	}
}