
/*
WAP to display x power n using method where power= digit count of num
*/

class p18
{
	static int power(int base, int pow)
	{
		int res = 1;
		for (int i=1; i<=pow; i++)
		{
			res *= base;
		}
		return res;
	}
	static int digitCount(int num)
	{
		int counter = 0;
		while (num > 0)
		{
			num/=10;
			counter++;
		}
		return counter;
	}
	public static void main(String[] args) 
	{
		int num =11;
		//System.out.println(power(2,3));
		//System.out.println(power(4,digitCount(2)));
		System.out.println(power(num,digitCount(num)));
	}
}
