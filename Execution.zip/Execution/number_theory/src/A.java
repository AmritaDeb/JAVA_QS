class A 
{

	A(int i)
	{

	}
}
class B extends A
{ 
	public static void main(String[] args) 
	{
		
	}
}
