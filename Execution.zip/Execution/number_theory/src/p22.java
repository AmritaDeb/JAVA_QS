
/* A method to obtain nth factorial by recursive logic */

class p22
{
	public static int fact(int num)
	{
		if (num == 1)
		{
			return 1;
		}		
		//return num * fact(num-1);
		return num * fact(--num);
	}
	public static void main(String[] args) 
	{		
		System.out.println("factorials:" + fact(5));
	}
}