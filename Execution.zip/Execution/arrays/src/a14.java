
// Display the array elements of integer in ascending order

class a14
{
	public static void main(String[] args) 
	{
		int [] a = {100,87,85,20};
		for (int i=0; i<a.length-1; i++)
		{
			for (int j=i+1; j<a.length; j++)
			{
				if (a[i] > a[j])
				{
					a[i] = a[i] + a[j];
					a[j] = a[i] - a[j];
					a[i] = a[i] - a[j];
				}
			}
		}
		for (int i=0; i<a.length; i++)
		{
			System.out.println(a[i]);
		}
	}
}
