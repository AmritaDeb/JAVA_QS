
//BubbleSort

class BubbleSort
{
	public static void main(String[] args) 
	{
		int [] a = {10, 5, 3, 2};
		for (int p=0; p < a.length-1; p++)
		{
			for (int i=0; i < a.length-1-p; i++)
			{
				if (a[i] > a[i+1])
				{
					int temp = a[i];
					a[i] = a[i+1];
					a[i+1] = temp;
				}
			}
		}
		for (int i=0; i < a.length; i++)
		{
			System.out.println(a[i]);
		}
	}
}


