
/*
	1.WAP to accept any five integer values, create an array such that if the array elemnets is divisible by 5
	the corresponding new elements should be 0
	else it should be 1  [10,5,27,32,50] = [1,1,0,0,1]
	2.
*/

import java.util.Scanner;

class a10
{
	static Scanner s = new Scanner(System.in);
	public static void main(String[] args) 
	{
		System.out.println("Enter the size of the array:");
		int size = s.nextInt();
		
		int [] a =new int[size];
		int [] r =new int[size];

		System.out.println("Enter the elements:");


		for (int i=0; i<a.length; i++)
		{
			a[i] = s.nextInt();
			if (a[i] % 5 == 0)
			{
				r[i]=1;
			}
			else
				r[i]=0;
			
		}
		System.out.println("--------------------------");

		for (int j=0; j<r.length; j++)
		{
			System.out.println(r[j]);
		}
		//System.out.println("The number of consonants present: "+ cons_count);
	}
}

/*
	
	1. Read a string from a user and display the string such that every alternative character from the first character of a string is in uppercase
	and remaining character should be in lower case. [ aPpLe ] 

*/