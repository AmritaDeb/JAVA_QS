
class a8
{
	public static void main(String[] args) 
	{
		String s1 = "Welcome to Bangalore";
		char[] ch = s1.toCharArray();
		int ln=new int 
		int wc1 = 0
		for (int i=0; i<ch.length;i++)
		{			
				length++;
				i++;
		}
			Sy+stem.out.println("The length of word: " + count + "is: " + length);
	}
		System.out.println("The no of words are: " + count);
}
		
		
		
/*
	1.
	2. Write a program to ontain no of words along with their length
	3.
	4. Write a program to count no of vowel that begin
	5. wap to count no of spaces in sentence
	6. wap to remove extra space bw words
	7. Remove extra space between words
	8. wap to convert a sentence into init cap case

*/