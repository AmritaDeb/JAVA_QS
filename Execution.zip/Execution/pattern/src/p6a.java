
/*
	1 2 3
	1 2 3
	1 2 3
*/

class p6a 
{
	public static void main(String[] args) 
	{
		int row = 3;
		int col = 3;
		
		for (int j=0; j<row; j++)
		{
			for (int i=0; i<col; i++)
			{
				System.out.print(i+1);
			}
			System.out.println();
			System.out.println();
			
		}
	}
}
