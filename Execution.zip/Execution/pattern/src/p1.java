
/*
	* * *
	* * *
	* * *
*/

class p1 
{
	public static void main(String[] args) 
	{
		int rows = 3;
		int col = 3;
		for (int j=0; j<rows; j++)
		{
			for (int i=0; i<col; i++)
			{
				System.out.print("* ");
			}
			System.out.println();
			System.out.println();
		}
	}
}
