
/*
	11111
	00000
	33333
	00000
	55555
*/

class p10
{
	public static void main(String[] args) 
	{
		int row = 5;
		int col = 5;

		for (int i=0; i<row; i++)
		{
			for (int j=0; j<col; j++)
			{
				if (i%2==1)
				{
					System.out.print(0);
				}
				else
					System.out.print(i+1);
			}
			System.out.println();
		}
	}
}
