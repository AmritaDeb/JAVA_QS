
/*
	* * *
	* * *
	* * *
	* * *
	* * *
*/

class p3 
{
	public static void main(String[] args) 
	{
		int row = 5;
		int col = 3;

		for (int j=0; j<row; j++)
		{
			for (int i=0; i<col; i++)
			{
				System.out.print("* ");
			}
			System.out.println();
			System.out.println();
		}
	}
}
