
/*
	* * * * *
	* * * * *
	* * * * *
*/

class p2 
{
	public static void main(String[] args) 
	{
		int rows = 3;
		int col = 5;
		for (int j=0; j<rows; j++)
		{
			for (int i=0; i<col; i++)
			{
				System.out.print("* ");
			}
			System.out.println();
			System.out.println();
		}
	}
}
