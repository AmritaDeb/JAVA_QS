
import stack1.MyStack;

class a1
{
	public static void main(String[] args) 
	{
		MyStack ms = new MyStack();
		ms.push(10);
		ms.push(20);
		ms.push(5);
		ms.push(30);
		System.out.println(ms.seek());
	}
}