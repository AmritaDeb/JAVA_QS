
package stack1;
import java.util.*;

class MyStack
{
	public static ArrayList<Integer> ls = new ArrayList<>();

	public static void push(int a)
	{
		ls.add(0,a);
	}
	public static int seek()
	{
		int a = ls.get(0);
		return a;
	}
	public static int pop()
	{
		int a = ls.get(0);
		ls.remove(0);
		return a;
	}

	public static void main(String[] args) 
	{
		push(10);
		push(20);
		push(30);
		push(40);
		System.out.println(ls);
		System.out.println(seek());
		pop();
		System.out.println(seek());
		System.out.println(ls);
		
	}
}
