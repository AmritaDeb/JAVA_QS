
package hmap ;

import java.util.* ;

class   G
{
	public static void main(String[] args) 
	{
		TreeMap <Integer , String> m = new TreeMap<>() ;
		Scanner sc = new Scanner(System.in) ;
		m.put(5 ,"sheela") ;
		m.put(1 ,"dosa") ;
		m.put(3,"idli") ;
		m.put(2,"Sambar") ;
		System.out.println(m) ;
	}
}




